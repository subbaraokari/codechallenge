import {React,Component} from 'react';
import Products from './components/products/products';
class App extends Component{
  render(){
    return(
      <div>
        <Products/>
      </div>
    )
  }
}
export default App;